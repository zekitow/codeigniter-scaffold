<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<style type="text/css">
		::moz-selection,::selection,::webkit-selection{background-color:#E13300;color:#fff}body{background-color:#fff;margin:40px;font:13px/20px normal Helvetica,Arial,sans-serif;color:#4F5155}a{color:#039;background-color:transparent;font-weight:400}h1,h2{color:#444;background-color:transparent;border-bottom:1px solid #D0D0D0;font-size:19px;font-weight:400;margin:0 0 14px;padding:14px 15px 10px}code{font-family:Consolas,Monaco,Courier New,Courier,monospace;font-size:12px;background-color:#f9f9f9;border:1px solid #D0D0D0;color:#002166;display:block;margin:14px 0;padding:12px 10px}.body{margin:0 15px}p.footer{text-align:right;font-size:11px;border-top:1px solid #D0D0D0;line-height:32px;padding:0 10px;margin:20px 0 0}#container{margin:10px;border:1px solid #D0D0D0;-webkit-box-shadow:0 0 8px #D0D0D0}
	</style>
</head>
<body>

<div id="container">
	<h1>Welcome to CodeIgniter Scaffold 2.0!</h1>

	<div class="body">
		<p>The page you are looking at is being generated dynamically by CodeIgniter.</p>

		<p>If you would like to edit this page you'll find it located at:</p>
		<code>application/views/welcome_message.php</code>

		<p>The corresponding controller for this page is found at:</p>
		<code>application/controllers/welcome.php</code>

		<p>If you are exploring CodeIgniter Scaffold for the very first time, you should start by reading the <a href="https://github.com/zekitow/codeigniter-scaffold" target="_blank">User Guide</a>.</p>
	</div>
	<div class="body">
		<h2>Get Started!</h2>
		<p>How to use the Codeginiter-Scaffold?</p>
		<code>
			codeigniter-scaffold [options...]<br/>
			  -h, --help show this help<br/>
			  -i, --init unzip a codeigniter 2.1.2 installaion in the current dir<br/>
			  -s, --scaffold <b>ModelName</b> field1:string, field2:text field3:integer, and so on..<br/>
		</code>

		<h2>Pre-Setup</h2>
		<p>1. After running "codeigniter-scaffold -–init":</p>
		<code>
			Open 'application/config/config.php' and set-up the 'base_url' property;<br/>
			Open 'application/config/database.php' and set-up your database settings;<br/>
		</code>

		<p>2. After running 'codeigniter-scaffold –scaffold [options…]':</p>
		<code>Go to 'application/migrations' and run the generated script into your database;</code>

		<h2>Video Tutorial</h2>
		<p>Check out the video that show how to use codeigniter-scaffold at <a href="https://www.youtube.com/watch?v=2Djlz7nP1ks" target="_blank">youtube.com</a>.</p> 
		<p> If you found any bug, question or want to ask for a feature, please, visit my GitHub at <a href="https://github.com/zekitow/" target="_blank">https://github.com/zekitow/</a>.</p>

		<p><b>THANKS FOR USING CODEIGNITER-SCAFFOLD!</b></p>
	</div>

	<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
</div>

</body>
</html>